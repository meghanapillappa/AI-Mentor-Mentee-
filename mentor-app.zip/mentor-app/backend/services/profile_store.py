"""
In-memory store backing the Mentor View / Mentee View "profile" features:

    - Mentor notes + contacted flag on a specific mentee
    - Mentee self-service contact info (email/phone)
    - A simple mentee <-> mentor message thread

Same caveat as auth.py: this is in-memory only and resets whenever the
Flask process restarts. Fine for an internal tool; swap for a real DB if
this needs to survive restarts.

No Flask-specific code lives here (no `request`/`jsonify`), so it's owned
entirely by routes/profile_routes.py.
"""

import datetime

# {"<mentor>::<uid>": {"note": str, "contacted": bool}}
MENTOR_NOTES = {}

# {uid: {"email": str, "phone": str}}
MENTEE_CONTACT = {}

# {uid: [{"sender": "mentee"|"mentor", "text": str, "ts": iso8601}]}
MESSAGE_THREADS = {}


def _note_key(mentor, uid):
    return f"{mentor}::{uid}"


def set_mentor_note(mentor, uid, note=None, contacted=None):
    """Upserts the note and/or contacted flag a mentor has left on one of
    their mentees. Either field can be omitted to leave it unchanged."""
    key = _note_key(mentor, uid)
    entry = MENTOR_NOTES.setdefault(key, {"note": "", "contacted": False})
    if note is not None:
        entry["note"] = note
    if contacted is not None:
        entry["contacted"] = bool(contacted)
    return entry


def get_mentor_notes(mentor, uids):
    """Returns {uid: {"note": ..., "contacted": ...}} for every uid given,
    defaulting to a blank entry for any uid with no note yet."""
    return {
        uid: MENTOR_NOTES.get(_note_key(mentor, uid), {"note": "", "contacted": False})
        for uid in uids
    }


def set_mentee_contact(uid, email=None, phone=None):
    entry = MENTEE_CONTACT.setdefault(uid, {"email": "", "phone": ""})
    if email is not None:
        entry["email"] = email
    if phone is not None:
        entry["phone"] = phone
    return entry


def get_mentee_contact(uid):
    return MENTEE_CONTACT.get(uid, {"email": "", "phone": ""})


def add_message(uid, sender, text):
    if sender not in ("mentee", "mentor"):
        raise ValueError("sender must be 'mentee' or 'mentor'")
    text = (text or "").strip()
    if not text:
        raise ValueError("Message text cannot be empty")
    msg = {
        "sender": sender,
        "text": text,
        "ts": datetime.datetime.utcnow().isoformat() + "Z",
    }
    MESSAGE_THREADS.setdefault(uid, []).append(msg)
    return msg


def get_messages(uid):
    return MESSAGE_THREADS.get(uid, [])
