"""
App entrypoint. This file should stay thin: create the app, enable CORS,
register each feature's blueprint, and run.

Adding a whole new feature area (e.g. a notifications API)? Create
routes/notifications_routes.py with its own Blueprint and register it below
— you shouldn't need to touch any other route file to do it.
"""

from flask import Flask
from flask_cors import CORS

from routes.file_routes import file_bp
from routes.match_routes import match_bp
from routes.auth_routes import auth_bp
from routes.profile_routes import profile_bp


app = Flask(__name__)
# Enable CORS to allow your separate Frontend UI to communicate with this Backend
CORS(app, expose_headers=["Authorization"], allow_headers=["Content-Type", "Authorization"])

app.register_blueprint(auth_bp)
app.register_blueprint(file_bp)
app.register_blueprint(match_bp)
app.register_blueprint(profile_bp)


if __name__ == '__main__':
    app.run(port=5001, debug=True)
