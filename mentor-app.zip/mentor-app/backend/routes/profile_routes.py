"""
Profile routes: back the Mentor View and Mentee View homepages.

    Mentor View  -> notes + contacted flag on their mentees (roster export
                    itself reuses /api/save-file from file_routes.py)
    Mentee View  -> self-service contact info, and a message thread to
                    their mentor

These are reached from the role-picker home page as *views* an already
logged-in admin can switch into (see auth.py) — mentors/mentees don't get
their own accounts. The frontend already carries a stable per-student `uid`
around (see state.js / assignUids), so every endpoint here just keys off
that uid and doesn't need to know anything about the current match itself.

If you're adding a new mentor/mentee self-service feature, this is the file
to touch; the storage itself lives in services/profile_store.py.
"""

from flask import Blueprint, jsonify, request
from auth import require_auth

from services.profile_store import (
    set_mentor_note,
    get_mentor_notes,
    set_mentee_contact,
    get_mentee_contact,
    add_message,
    get_messages,
)

profile_bp = Blueprint("profile_bp", __name__)


# ---------------------------------------------------------------------
# Mentor View: notes + contacted flag on their mentees
# ---------------------------------------------------------------------

@profile_bp.route("/api/mentor-notes", methods=["POST"])
@require_auth()
def save_mentor_note_route():
    """Body: { mentor, uid, note?, contacted? } -> saves whichever fields
    were provided and returns the resulting {note, contacted} entry."""
    data = request.get_json(silent=True) or {}
    mentor = (data.get("mentor") or "").strip()
    uid = data.get("uid")

    if not mentor or not uid:
        return jsonify({"error": "mentor and uid are required"}), 400

    entry = set_mentor_note(mentor, uid, note=data.get("note"), contacted=data.get("contacted"))
    return jsonify(entry)


@profile_bp.route("/api/mentor-notes/<mentor>", methods=["POST"])
@require_auth()
def bulk_mentor_notes_route(mentor):
    """Body: { uids: [...] } -> { uid: {note, contacted}, ... } for every
    uid in the mentor's current roster, so the Mentor View can render a
    fresh table in one round trip instead of one request per mentee."""
    data = request.get_json(silent=True) or {}
    uids = data.get("uids", [])
    return jsonify(get_mentor_notes(mentor, uids))


# ---------------------------------------------------------------------
# Mentee View: self-service contact info
# ---------------------------------------------------------------------

@profile_bp.route("/api/mentee-contact/<uid>", methods=["GET"])
@require_auth()
def get_mentee_contact_route(uid):
    return jsonify(get_mentee_contact(uid))


@profile_bp.route("/api/mentee-contact/<uid>", methods=["POST"])
@require_auth()
def save_mentee_contact_route(uid):
    data = request.get_json(silent=True) or {}
    entry = set_mentee_contact(uid, email=data.get("email"), phone=data.get("phone"))
    return jsonify(entry)


# ---------------------------------------------------------------------
# Messaging: one thread per mentee uid, shared by Mentor View & Mentee View
# ---------------------------------------------------------------------

@profile_bp.route("/api/messages/<uid>", methods=["GET"])
@require_auth()
def get_messages_route(uid):
    return jsonify(get_messages(uid))


@profile_bp.route("/api/messages/<uid>", methods=["POST"])
@require_auth()
def post_message_route(uid):
    """Body: { sender: 'mentee'|'mentor', text }"""
    data = request.get_json(silent=True) or {}
    try:
        msg = add_message(uid, data.get("sender"), data.get("text"))
    except ValueError as ve:
        return jsonify({"error": str(ve)}), 400
    return jsonify(msg)
