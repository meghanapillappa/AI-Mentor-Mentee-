// ---------------------------------------------------------------------------
// shared.js
//
// Loaded on EVERY page (login.html, home.html, admin.html, mentor.html,
// mentee.html), before any page-specific script. Owns two things:
//
//   1. Auth: only the admin actually logs in (see backend/auth.py — there's
//      no separate mentor/mentee account system). The token from
//      POST /api/login is cached in localStorage so the admin can jump
//      between the Admin / Mentor / Mentee homepages without re-entering a
//      password on each one. requireAuth() is the guard every protected
//      page calls on load.
//
//   2. Match hand-off: mentorsData/studentsData/lastCohorts normally only
//      live in admin.html's in-memory JS state (see state.js). Mentor View
//      and Mentee View are separate pages/reloads, so saveMatchState() /
//      loadMatchState() shuttle the last computed match through
//      localStorage instead of requiring a new backend endpoint just to
//      pass data between pages of the same browser session.
// ---------------------------------------------------------------------------

const API_BASE = 'http://127.0.0.1:5001';

const AUTH_STORAGE_KEY = 'mde_auth';
const MATCH_STORAGE_KEY = 'mde_last_match';

function getAuth() {
  try {
    return JSON.parse(localStorage.getItem(AUTH_STORAGE_KEY) || 'null');
  } catch {
    return null;
  }
}

function setAuth(auth) {
  localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(auth));
}

function clearAuth() {
  localStorage.removeItem(AUTH_STORAGE_KEY);
}

function authHeader() {
  const auth = getAuth();
  return auth ? { 'Authorization': `Bearer ${auth.token}` } : {};
}

/**
 * Call at the top of every protected page. Redirects to login.html if
 * there's no cached token, or if the backend rejects it (e.g. the Flask
 * process restarted and dropped its in-memory sessions — see auth.py).
 * Returns the auth object ({token, username, role}) on success, or null
 * (after redirecting) on failure.
 */
async function requireAuth() {
  const auth = getAuth();
  if (!auth) {
    window.location.href = 'login.html';
    return null;
  }
  try {
    const res = await fetch(`${API_BASE}/api/me`, { headers: authHeader() });
    if (!res.ok) throw new Error('invalid session');
    return auth;
  } catch {
    clearAuth();
    window.location.href = 'login.html';
    return null;
  }
}

function logout() {
  const headers = authHeader();
  fetch(`${API_BASE}/api/logout`, { method: 'POST', headers }).finally(() => {
    clearAuth();
    window.location.href = 'login.html';
  });
}

/** Called from matching.js right after a match/rebalance succeeds, so the
 * Mentor View / Mentee View pages can read the same result. */
function saveMatchState() {
  try {
    localStorage.setItem(MATCH_STORAGE_KEY, JSON.stringify({
      mentorsData,
      studentsData,
      lastCohorts,
      savedAt: Date.now(),
    }));
  } catch (e) {
    console.error('Could not persist match state for Mentor/Mentee views:', e);
  }
}

/** Read by mentorView.js / menteeView.js. Returns null if Admin hasn't run
 * a match yet. */
function loadMatchState() {
  try {
    const raw = localStorage.getItem(MATCH_STORAGE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

/** Wires up the "Home" / "Log out" buttons that appear in every page's
 * header nav, if present on the current page. Safe to call unconditionally. */
function wireHeaderNav() {
  const logoutBtn = document.getElementById('logout-btn');
  if (logoutBtn) logoutBtn.addEventListener('click', logout);
}

document.addEventListener('DOMContentLoaded', wireHeaderNav);
