// ---------------------------------------------------------------------------
// auth.js
//
// login.html only. POSTs to /api/login, caches the token via setAuth()
// (shared.js), then sends the admin to the role picker.
// ---------------------------------------------------------------------------

document.addEventListener('DOMContentLoaded', () => {
  // Already logged in? Skip straight to the role picker.
  if (getAuth()) {
    window.location.href = 'home.html';
    return;
  }

  document.getElementById('login-btn').addEventListener('click', doLogin);
  document.getElementById('login-password').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') doLogin();
  });
});

async function doLogin() {
  const username = document.getElementById('login-username').value.trim();
  const password = document.getElementById('login-password').value;
  const statusEl = document.getElementById('login-status');

  if (!username || !password) {
    setStatus(statusEl, 'Enter a username and password.', 'err');
    return;
  }

  try {
    const res = await fetch(`${API_BASE}/api/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Login failed');
    setAuth(data);
    window.location.href = 'home.html';
  } catch (err) {
    setStatus(statusEl, err.message, 'err');
  }
}
