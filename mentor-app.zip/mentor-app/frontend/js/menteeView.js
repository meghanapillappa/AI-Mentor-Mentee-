// ---------------------------------------------------------------------------
// menteeView.js
//
// Mentee View homepage. Pick your own name from the last match Admin ran
// (there's no separate mentee login — see auth.py), then a single profile
// box: your assigned mentor, your grade/section/CGPA, editable contact
// info (email/phone — /api/mentee-contact), and a message thread to your
// mentor (/api/messages).
//
// Depends on: shared.js (requireAuth/authHeader/loadMatchState), utils.js
// (setStatus).
// ---------------------------------------------------------------------------

async function initMenteeView() {
  const auth = await requireAuth();
  if (!auth) return;

  const state = loadMatchState();
  const selector = document.getElementById('mentee-select');
  const emptyNote = document.getElementById('mentee-view-empty');

  if (!state || !state.lastCohorts || !state.lastCohorts.length) {
    emptyNote.style.display = 'block';
    selector.disabled = true;
    return;
  }

  const allStudents = [];
  state.lastCohorts.forEach(c => c.students.forEach(s => allStudents.push({ ...s, mentor: c.mentor })));

  selector.innerHTML = '<option value="">Select your name…</option>' +
    allStudents
      .slice()
      .sort((a, b) => a.name.localeCompare(b.name))
      .map(s => `<option value="${s.uid}">${s.name}</option>`)
      .join('');

  selector.addEventListener('change', () => renderMenteeBox(selector.value, allStudents));
}

async function renderMenteeBox(uid, allStudents) {
  const box = document.getElementById('mentee-profile-box');
  if (!uid) {
    box.innerHTML = '';
    return;
  }

  const student = allStudents.find(s => String(s.uid) === String(uid));
  if (!student) {
    box.innerHTML = '';
    return;
  }

  box.innerHTML = "<p class='empty-note'>Loading profile…</p>";

  let contact = { email: '', phone: '' };
  let messages = [];
  try {
    const [contactRes, msgRes] = await Promise.all([
      fetch(`${API_BASE}/api/mentee-contact/${encodeURIComponent(uid)}`, { headers: authHeader() }),
      fetch(`${API_BASE}/api/messages/${encodeURIComponent(uid)}`, { headers: authHeader() })
    ]);
    contact = await contactRes.json();
    messages = await msgRes.json();
  } catch (e) {
    console.error('Could not load mentee profile data:', e);
  }

  box.innerHTML = `
    <div class="dataset-editor-header">
      <h3>${student.name}</h3>
      <span>Grade ${student.Grade} &middot; Section ${student.Section} &middot; CGPA ${student.CGPA.toFixed(2)}</span>
    </div>
    <p style="margin:6px 0 18px; font-size:13.5px;">
      Your assigned mentor: <strong>${student.mentor}</strong>
    </p>

    <div class="panel-section-title">Your contact info</div>
    <div style="display:flex; gap:14px; margin:14px 0; flex-wrap:wrap;">
      <div class="upload-group" style="flex:1; min-width:180px;">
        <label>Email</label>
        <input type="text" id="mentee-email" value="${(contact.email || '').replace(/"/g, '&quot;')}" placeholder="you@example.com">
      </div>
      <div class="upload-group" style="flex:1; min-width:180px;">
        <label>Phone</label>
        <input type="text" id="mentee-phone" value="${(contact.phone || '').replace(/"/g, '&quot;')}" placeholder="+91 ...">
      </div>
    </div>
    <div style="display:flex; align-items:center; gap:10px;">
      <button class="ghost-btn" id="mentee-save-contact-btn">Save contact info</button>
      <div id="mentee-contact-status" class="status-line"></div>
    </div>

    <div class="panel-section-title" style="margin-top:24px;">Message ${student.mentor}</div>
    <div class="message-thread" id="mentee-message-thread"></div>
    <div class="message-compose">
      <input type="text" id="mentee-message-input" placeholder="Write a message…">
      <button class="ghost-btn" id="mentee-send-btn">Send</button>
    </div>
  `;

  renderMenteeMessageThread(messages);

  document.getElementById('mentee-save-contact-btn').addEventListener('click', async () => {
    const email = document.getElementById('mentee-email').value.trim();
    const phone = document.getElementById('mentee-phone').value.trim();
    const statusEl = document.getElementById('mentee-contact-status');
    try {
      await fetch(`${API_BASE}/api/mentee-contact/${encodeURIComponent(uid)}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...authHeader() },
        body: JSON.stringify({ email, phone })
      });
      setStatus(statusEl, 'Saved.', 'ok');
    } catch (err) {
      setStatus(statusEl, `Could not save: ${err.message}`, 'err');
    }
  });

  document.getElementById('mentee-send-btn').addEventListener('click', async () => {
    const input = document.getElementById('mentee-message-input');
    const text = input.value.trim();
    if (!text) return;
    try {
      const res = await fetch(`${API_BASE}/api/messages/${encodeURIComponent(uid)}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...authHeader() },
        body: JSON.stringify({ sender: 'mentee', text })
      });
      const msg = await res.json();
      if (!res.ok) throw new Error(msg.error || 'Failed to send');
      messages.push(msg);
      renderMenteeMessageThread(messages);
      input.value = '';
    } catch (err) {
      alert(`Could not send message: ${err.message}`);
    }
  });
}

function renderMenteeMessageThread(messages) {
  const thread = document.getElementById('mentee-message-thread');
  if (!messages.length) {
    thread.innerHTML = "<p class='empty-note' style='padding:6px 0;'>No messages yet.</p>";
    return;
  }
  thread.innerHTML = messages.map(m => `
    <div class="message-bubble ${m.sender === 'mentee' ? 'from-mentee' : 'from-mentor'}">${m.text}</div>
  `).join('');
  thread.scrollTop = thread.scrollHeight;
}

document.addEventListener('DOMContentLoaded', initMenteeView);
