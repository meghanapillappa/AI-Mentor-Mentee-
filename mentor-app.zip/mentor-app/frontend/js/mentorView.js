// ---------------------------------------------------------------------------
// mentorView.js
//
// Mentor View homepage. One box, one job: pick a mentor from the last match
// Admin ran, and see every one of their mentees in a single table — with a
// per-mentee "contacted" checkbox and note (persisted via
// /api/mentor-notes), and a "Export my roster" button that reuses
// /api/save-file. A small message icon per row opens that mentee's thread
// so the mentor can read/reply (backend: /api/messages/<uid>).
//
// Depends on: shared.js (requireAuth/authHeader/loadMatchState), api.js
// (apiSaveFile), utils.js (setStatus).
// ---------------------------------------------------------------------------

let mentorViewCohorts = [];

async function initMentorView() {
  const auth = await requireAuth();
  if (!auth) return;

  const state = loadMatchState();
  const selector = document.getElementById('mentor-select');
  const emptyNote = document.getElementById('mentor-view-empty');

  if (!state || !state.lastCohorts || !state.lastCohorts.length) {
    emptyNote.style.display = 'block';
    selector.disabled = true;
    return;
  }

  mentorViewCohorts = state.lastCohorts;
  selector.innerHTML = '<option value="">Select a mentor…</option>' +
    mentorViewCohorts
      .map(c => `<option value="${c.mentor}">${c.mentor} (${c.student_count} mentee${c.student_count === 1 ? '' : 's'})</option>`)
      .join('');

  selector.addEventListener('change', () => renderMentorBox(selector.value));
}

async function renderMentorBox(mentorName) {
  const box = document.getElementById('mentor-mentee-box');
  if (!mentorName) {
    box.innerHTML = '';
    return;
  }

  const cohort = mentorViewCohorts.find(c => c.mentor === mentorName);
  if (!cohort) {
    box.innerHTML = '';
    return;
  }

  box.innerHTML = "<p class='empty-note'>Loading roster…</p>";

  const uids = cohort.students.map(s => s.uid).filter(Boolean);
  let notes = {};
  try {
    const res = await fetch(`${API_BASE}/api/mentor-notes/${encodeURIComponent(mentorName)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...authHeader() },
      body: JSON.stringify({ uids })
    });
    notes = await res.json();
  } catch (e) {
    console.error('Could not load mentor notes:', e);
  }

  const rows = cohort.students.map(s => {
    const n = notes[s.uid] || { note: '', contacted: false };
    return `
      <tr data-uid="${s.uid || ''}">
        <td><strong>${s.name}</strong></td>
        <td><span class="grade-pill grade-${s.Grade.toLowerCase()}">${s.Grade}</span></td>
        <td>Section ${s.Section}</td>
        <td class="col-gpa">${s.CGPA.toFixed(2)}</td>
        <td style="text-align:center;"><input type="checkbox" class="contacted-check" ${n.contacted ? 'checked' : ''}></td>
        <td><input type="text" class="note-input" value="${(n.note || '').replace(/"/g, '&quot;')}" placeholder="Add a note…"></td>
        <td style="text-align:center;"><button class="ghost-btn msg-btn" title="Messages" ${s.uid ? '' : 'disabled'}>💬</button></td>
      </tr>
    `;
  }).join('');

  box.innerHTML = `
    <div class="dataset-editor-header">
      <h3>${mentorName}'s mentees</h3>
      <span>${cohort.student_count} mentee(s) &middot; avg GPA ${cohort.average_gpa.toFixed(3)}</span>
    </div>
    <div class="editable-table-wrapper" style="max-height:420px;">
      <table class="editable-table">
        <thead>
          <tr><th>Name</th><th>Grade</th><th>Section</th><th>CGPA</th><th>Contacted</th><th>Note</th><th>Messages</th></tr>
        </thead>
        <tbody>${rows}</tbody>
      </table>
    </div>
    <div class="dataset-editor-footer">
      <span class="muted" style="font-size:11.5px;">Notes and contacted status save automatically.</span>
      <button class="ghost-btn" id="mentor-export-btn">Export my roster</button>
    </div>
  `;

  box.querySelectorAll('tr[data-uid]').forEach(tr => {
    const uid = tr.dataset.uid;
    if (!uid) return;
    const student = cohort.students.find(s => String(s.uid) === String(uid));

    tr.querySelector('.contacted-check').addEventListener('change', (e) => {
      saveMentorNote(mentorName, uid, { contacted: e.target.checked });
    });

    tr.querySelector('.note-input').addEventListener('change', (e) => {
      saveMentorNote(mentorName, uid, { note: e.target.value });
    });

    tr.querySelector('.msg-btn').addEventListener('click', () => {
      openMentorMessageModal(uid, student ? student.name : 'Mentee');
    });
  });

  document.getElementById('mentor-export-btn').addEventListener('click', () => exportMentorRoster(cohort));
}

async function saveMentorNote(mentor, uid, fields) {
  try {
    await fetch(`${API_BASE}/api/mentor-notes`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...authHeader() },
      body: JSON.stringify({ mentor, uid, ...fields })
    });
  } catch (err) {
    console.error('Could not save mentor note:', err);
  }
}

async function exportMentorRoster(cohort) {
  const rows = cohort.students.map(s => ({
    Name: s.name, Grade: s.Grade, Section: s.Section, CGPA: s.CGPA
  }));
  const filenameBase = `${cohort.mentor.replace(/\s+/g, '_')}_roster`;
  try {
    const response = await apiSaveFile(rows, 'csv', filenameBase);
    const blob = await response.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${filenameBase}.csv`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    window.URL.revokeObjectURL(url);
  } catch (err) {
    alert(`Export failed: ${err.message}`);
  }
}

// ---------------------------------------------------------------------------
// Mentor-side message modal (reply to a mentee's messages)
// ---------------------------------------------------------------------------

function openMentorMessageModal(uid, studentName) {
  const overlay = document.createElement('div');
  overlay.setAttribute('role', 'dialog');
  overlay.setAttribute('aria-modal', 'true');
  overlay.style.cssText =
    'position:fixed; inset:0; background:rgba(0,0,0,0.45); display:flex; align-items:center; justify-content:center; z-index:1000;';

  const modal = document.createElement('div');
  modal.className = 'view-box';
  modal.style.cssText = 'width:420px; max-width:90vw; max-height:80vh; overflow-y:auto; background:var(--bg-card);';
  modal.innerHTML = `
    <div class="dataset-editor-header">
      <h3>Messages with ${studentName}</h3>
    </div>
    <div class="message-thread" id="modal-message-thread"></div>
    <div class="message-compose">
      <input type="text" id="modal-message-input" placeholder="Write a reply…">
      <button class="ghost-btn" id="modal-send-btn">Send</button>
    </div>
    <div class="dataset-editor-footer" style="justify-content:flex-end;">
      <button class="ghost-btn" id="modal-close-btn">Close</button>
    </div>
  `;

  overlay.appendChild(modal);
  document.body.appendChild(overlay);

  const threadEl = modal.querySelector('#modal-message-thread');
  let messages = [];

  async function loadThread() {
    threadEl.innerHTML = "<p class='empty-note'>Loading…</p>";
    try {
      const res = await fetch(`${API_BASE}/api/messages/${encodeURIComponent(uid)}`, { headers: authHeader() });
      messages = await res.json();
    } catch (e) {
      messages = [];
    }
    renderThread();
  }

  function renderThread() {
    if (!messages.length) {
      threadEl.innerHTML = "<p class='empty-note'>No messages yet.</p>";
      return;
    }
    threadEl.innerHTML = messages.map(m => `
      <div class="message-bubble ${m.sender === 'mentee' ? 'from-mentee' : 'from-mentor'}">${m.text}</div>
    `).join('');
    threadEl.scrollTop = threadEl.scrollHeight;
  }

  modal.querySelector('#modal-send-btn').addEventListener('click', async () => {
    const input = modal.querySelector('#modal-message-input');
    const text = input.value.trim();
    if (!text) return;
    try {
      const res = await fetch(`${API_BASE}/api/messages/${encodeURIComponent(uid)}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...authHeader() },
        body: JSON.stringify({ sender: 'mentor', text })
      });
      const msg = await res.json();
      if (!res.ok) throw new Error(msg.error || 'Failed to send');
      messages.push(msg);
      renderThread();
      input.value = '';
    } catch (err) {
      alert(`Could not send message: ${err.message}`);
    }
  });

  modal.querySelector('#modal-close-btn').addEventListener('click', () => {
    document.body.removeChild(overlay);
  });

  loadThread();
}

document.addEventListener('DOMContentLoaded', initMentorView);
